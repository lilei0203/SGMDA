"""Package source, prepared public data and documentation, never partial results."""
from __future__ import annotations

import argparse
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=root.parent / "sgmda_5cv_project.zip")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Archive already exists; select another output filename")
    directories = ["sgmda", "scripts", "configs", "docs", "tests", "data/raw/mdformer", "data/processed"]
    allowed = {".py", ".json", ".md", ".csv", ".npz"}
    files = [root / name for name in ("README.md", "pyproject.toml", "requirements.txt", ".gitignore")]
    for name in directories:
        files.extend(p for p in (root / name).rglob("*") if p.is_file() and p.suffix in allowed
                     and "__pycache__" not in p.parts)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(args.output, mode="x", compression=ZIP_DEFLATED) as archive:
        for p in sorted(set(files)):
            archive.write(p, Path(root.name) / p.relative_to(root))
    print(f"Packaged {len(set(files))} files: {args.output} ({args.output.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
