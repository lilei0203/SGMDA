"""Score named pairs with one saved fold model (not a model trained on all data).

Input CSV columns: disease,mirna. Models must be generated with --save-models.
Only load trusted local model files: joblib deserialization can execute code.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", type=Path, required=True)
    parser.add_argument("--run", type=int, default=1)
    parser.add_argument("--fold", type=int, default=1)
    parser.add_argument("--data", type=Path, default=Path("data/processed/hmdd32.npz"))
    parser.add_argument("--pairs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    import joblib
    import numpy as np
    import torch
    from threadpoolctl import threadpool_limits
    from sgmda.data import file_sha256, load_dataset
    from sgmda.features import build_features
    from sgmda.model import SGMDA
    from sgmda.train import Config, extract_features

    if args.output.exists():
        parser.error("Output already exists; choose another filename")
    manifest = json.loads((args.experiment / "manifest.json").read_text(encoding="utf-8"))
    if file_sha256(args.data) != manifest["dataset_sha256"]:
        raise ValueError("Dataset differs from the one used to train this model")
    config = Config(**manifest["config"])
    config.device = "cpu"  # Portable inference, including GPU-trained state.
    if not 1 <= args.fold <= config.folds or not 1 <= args.run <= config.runs:
        parser.error("Run/fold out of range")
    folder = args.experiment / f"run_{args.run:02d}" / f"fold_{args.fold}"
    if not (folder / "complete.json").exists():
        raise ValueError("The selected fold is incomplete")
    if not (folder / "neural.pt").exists() or not (folder / "random_forest.joblib").exists():
        raise FileNotFoundError("Train with --save-models to enable inference")
    data = load_dataset(args.data)
    d_index = {str(name): i for i, name in enumerate(data.diseases)}
    m_index = {str(name): i for i, name in enumerate(data.mirnas)}
    with args.pairs.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or not {"disease", "mirna"}.issubset(reader.fieldnames):
            raise ValueError("Input CSV requires disease and mirna columns")
        rows = list(reader)
    if not rows:
        raise ValueError("Input CSV is empty")
    # Exact names only: do not silently merge precursor/mature miRNA IDs.
    try:
        pairs = np.asarray([(d_index[r["disease"]], m_index[r["mirna"]]) for r in rows], dtype=np.int64)
    except KeyError as exc:
        raise ValueError(f"Unknown entity name: {exc}; use names in the dataset") from exc
    audit = json.loads((folder / "audit.json").read_text(encoding="utf-8"))
    with np.load(folder / "training_associations.npz", allow_pickle=False) as z:
        a_train = z["associations"]
    torch.set_num_threads(config.threads)
    with threadpool_limits(limits=config.threads):
        features = build_features(a_train, data.disease_semantic, config.dim, config.graph_threshold, audit["seed"])
    model = SGMDA(features, config.gae_activation, config.highway_mode)
    model.load_state_dict(torch.load(folder / "neural.pt", map_location="cpu", weights_only=True))
    rf = joblib.load(folder / "random_forest.joblib")
    scores = rf.predict_proba(extract_features(model, pairs, config))[:, np.flatnonzero(rf.classes_ == 1)[0]]
    with np.load(args.experiment / f"run_{args.run:02d}" / "split.npz", allow_pickle=False) as z:
        training = z["pairs"][z["fold"] != args.fold - 1]
        trained_pairs = set(map(tuple, training.tolist()))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["disease", "mirna", "score", "prediction", "used_in_fold_training"])
        writer.writeheader()
        for row, pair, score in zip(rows, pairs, scores):
            writer.writerow({"disease": row["disease"], "mirna": row["mirna"], "score": float(score),
                             "prediction": int(score >= config.classification_threshold),
                             "used_in_fold_training": tuple(pair) in trained_pairs})
    print(f"Saved {len(rows)} scores to {args.output}")


if __name__ == "__main__":
    main()

