"""Download the published MDformer HMDD3 benchmark at an immutable commit.

Only the association matrix, entity names and disease SEMANTIC similarity
are imported. Full-data GIP and miRNA functional similarities are NOT used.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

COMMIT = "07223704e2effd1de43689e840ce5365b4317a36"
BASE = f"https://raw.githubusercontent.com/Linda908/MDformer/{COMMIT}/"
FILES = ["HMDD3/m_d.csv", "HMDD3/d_ss.csv", "HMDD3/disease number.csv", "HMDD3/miRNA name.csv"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("data/raw/mdformer"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = {"repository": "https://github.com/Linda908/MDformer", "commit": COMMIT,
                "dataset": "Published HMDD v3.2-derived benchmark (not the full raw HMDD release)", "files": []}
    for relative in FILES:
        url = BASE + quote(relative)
        dest = args.output / Path(relative).name
        if not dest.exists():
            for attempt in range(3):
                try:
                    with urlopen(Request(url, headers={"User-Agent": "SGMDA-research/0.1"}), timeout=90) as response:
                        content = response.read()
                    if content[:100].lstrip().lower().startswith(b"<!doctype html"):
                        raise ValueError("Received HTML instead of data")
                    dest.with_suffix(dest.suffix + ".part").write_bytes(content)
                    dest.with_suffix(dest.suffix + ".part").replace(dest)
                    break
                except Exception:
                    if attempt == 2:
                        raise
                    time.sleep(2 * (attempt + 1))
        content = dest.read_bytes()
        record = {"file": dest.name, "url": url, "bytes": len(content),
                  "sha256": hashlib.sha256(content).hexdigest()}
        manifest["files"].append(record)
        print(json.dumps(record), flush=True)
    (args.output / "download_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
