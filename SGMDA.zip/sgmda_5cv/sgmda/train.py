"""Training on a fold; RF predictions never backpropagate into neural layers."""
from __future__ import annotations

import random
from dataclasses import asdict, dataclass

import numpy as np
import torch
from sklearn.ensemble import RandomForestClassifier
from torch.nn import functional as F

from .features import FoldFeatures
from .model import SGMDA


@dataclass
class Config:
    runs: int = 20
    folds: int = 5
    seed: int = 2026
    dim: int = 64
    epochs: int = 100
    learning_rate: float = 0.001
    temperature: float = 0.2
    graph_threshold: float = 0.5
    classification_threshold: float = 0.5
    reconstruction_weight: float = 1.0
    contrastive_weight: float = 0.1
    supervised_weight: float = 1.0
    gae_activation: str = "relu"
    highway_mode: str = "auxiliary"
    batch_size: int = 4096
    rf_trees: int = 300
    rf_max_depth: int | None = None
    rf_min_samples_leaf: int = 1
    threads: int = 4
    device: str = "cpu"
    save_models: bool = False

    def validate(self):
        if self.folds != 5:
            raise ValueError("This project implements five-fold CV only")
        for name in ("runs", "dim", "epochs", "batch_size", "rf_trees", "rf_min_samples_leaf", "threads"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if not isinstance(self.seed, int) or not 0 <= self.seed < 2**31:
            raise ValueError("seed must be an integer in [0, 2**31)")
        for name in ("learning_rate", "temperature"):
            if not np.isfinite(getattr(self, name)) or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive and finite")
        if not 0 <= self.graph_threshold < 1 or not 0 <= self.classification_threshold <= 1:
            raise ValueError("Invalid threshold")
        for name in ("reconstruction_weight", "contrastive_weight", "supervised_weight"):
            if not np.isfinite(getattr(self, name)) or getattr(self, name) < 0:
                raise ValueError(f"{name} must be nonnegative and finite")
        if self.reconstruction_weight + self.contrastive_weight <= 0:
            raise ValueError("At least one GAE/contrastive objective is required")
        if self.gae_activation not in ("relu", "linear"):
            raise ValueError("gae_activation must be relu or linear")
        if self.highway_mode not in ("auxiliary", "fixed"):
            raise ValueError("Invalid highway mode")
        if self.highway_mode == "auxiliary" and self.supervised_weight <= 0:
            raise ValueError("Auxiliary mode requires a positive supervised loss weight")
        if self.device != "cpu" and not self.device.startswith("cuda"):
            raise ValueError("device must be cpu or cuda[:index]")


def seed_everything(seed: int, threads: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)


def gradient_norm(module):
    return float(sum((p.grad.detach().square().sum().item()
                      for p in module.parameters() if p.grad is not None)) ** 0.5)


def extract_features(model, pairs, config):
    model.eval()
    device = model.linear_d.device
    result = []
    with torch.no_grad():
        zd, zm = model.encode()
        for start in range(0, len(pairs), config.batch_size):
            batch = torch.as_tensor(pairs[start:start + config.batch_size], device=device)
            result.append(model.pair_features(batch, zd, zm).cpu().numpy())
    return np.concatenate(result)


def train_fold(features: FoldFeatures, train_pairs, train_labels, test_pairs,
               config: Config, seed: int, progress=None):
    """No test labels are accepted by this function, nor by model training."""
    config.validate()
    seed_everything(seed, config.threads)
    device = torch.device(config.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; use --device cpu")
    model = SGMDA(features, config.gae_activation, config.highway_mode).to(device)
    svd_before = (model.linear_d.clone(), model.linear_m.clone())
    highway_before = [p.detach().clone() for p in model.highway.parameters()]
    optimizer = torch.optim.Adam((p for p in model.parameters() if p.requires_grad), lr=config.learning_rate)
    pairs = torch.as_tensor(train_pairs, dtype=torch.long, device=device)
    labels = torch.as_tensor(train_labels, dtype=torch.float32, device=device)
    logs = []
    # One optimizer step per epoch. Chunked supervised backward passes accumulate
    # the EXACT full-training-set mean BCE gradient; no parameter update occurs
    # between chunks. This avoids retaining all Highway activations at once.
    for epoch in range(1, config.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        zd, zm = model.encode()
        rec, cl = model.regularizers(zd, zm, config.temperature)
        pred_loss = 0.0
        if model.training_scorer is not None:
            order = torch.randperm(len(labels), device=device)
            for start in range(0, len(labels), config.batch_size):
                ix = order[start:start + config.batch_size]
                hidden = model.pair_features(pairs[ix], zd, zm)
                logits = model.training_scorer(hidden).squeeze(1)
                bce = F.binary_cross_entropy_with_logits(logits, labels[ix], reduction="sum") / len(labels)
                (config.supervised_weight * bce).backward(retain_graph=True)
                pred_loss += bce.item()
        regularization = config.reconstruction_weight * rec + config.contrastive_weight * cl
        regularization.backward()
        gae_grad = gradient_norm(model.gae_d) + gradient_norm(model.gae_m)
        highway_grad = gradient_norm(model.highway)
        total = config.supervised_weight * pred_loss + regularization.item()
        if not np.isfinite(total) or not np.isfinite(gae_grad + highway_grad):
            raise FloatingPointError("Nonfinite training loss/gradient")
        optimizer.step()
        logs.append({"epoch": epoch, "reconstruction_loss": rec.item(), "contrastive_loss": cl.item(),
                     "association_BCE": pred_loss if model.training_scorer is not None else None,
                     "total_loss": total, "gae_gradient_norm": gae_grad, "highway_gradient_norm": highway_grad})
        if progress and (epoch == 1 or epoch % 10 == 0 or epoch == config.epochs):
            progress(logs[-1])
    if not (torch.equal(svd_before[0], model.linear_d) and torch.equal(svd_before[1], model.linear_m)):
        raise AssertionError("Fixed SVD representations changed")
    highway_delta = float(sum((p.detach() - initial).square().sum().item()
                             for p, initial in zip(model.highway.parameters(), highway_before)) ** 0.5)
    if config.highway_mode == "auxiliary" and highway_delta == 0:
        raise AssertionError("Highway did not learn; inspect its gradient path")
    x_train = extract_features(model, train_pairs, config)
    x_test = extract_features(model, test_pairs, config)
    rf = RandomForestClassifier(n_estimators=config.rf_trees, criterion="gini",
                                max_depth=config.rf_max_depth, max_features="sqrt",
                                min_samples_leaf=config.rf_min_samples_leaf,
                                bootstrap=True, n_jobs=config.threads, random_state=seed)
    rf.fit(x_train, train_labels)
    scores = rf.predict_proba(x_test)[:, np.flatnonzero(rf.classes_ == 1)[0]]
    diagnostics = {"highway_parameter_delta_l2": highway_delta, "svd_unchanged": True,
                   "feature_dimension": x_train.shape[1], "config": asdict(config)}
    return scores, model, rf, logs, diagnostics

