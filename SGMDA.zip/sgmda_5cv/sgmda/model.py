"""Fixed SVD + two GAEs + asymmetric contrastive alignment + Highway.

The auxiliary scorer is an EXPLICIT implementation extension: ordinary RF
cannot backpropagate. It is discarded for final RF predictions.
"""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F

from .features import FoldFeatures


class GAE(nn.Module):
    def __init__(self, nodes: int, dim: int, activation: str = "relu"):
        super().__init__()
        # X = I, so A_norm @ X @ W = A_norm @ W, without materializing I.
        self.weight = nn.Parameter(torch.empty(nodes, dim))
        nn.init.xavier_uniform_(self.weight)
        self.activation = activation

    def forward(self, graph):
        z = graph @ self.weight
        return F.relu(z) if self.activation == "relu" else z


def reconstruction_loss(z, target):
    mask = ~torch.eye(len(z), dtype=torch.bool, device=z.device)
    return F.binary_cross_entropy_with_logits((z @ z.T)[mask], target[mask])


def contrastive_loss(fixed, learned, temperature: float):
    """Fixed linear anchor; same entity in nonlinear view is the positive.

    Other entities in BOTH views are negatives. Exclude the anchor itself
    from its own denominator (explicit correction to the manuscript formula).
    """
    fixed = F.normalize(fixed.detach(), dim=1)
    learned = F.normalize(learned, dim=1)
    n = len(fixed)
    logits = fixed @ torch.cat((fixed, learned), dim=0).T / temperature
    mask = torch.zeros_like(logits, dtype=torch.bool)
    idx = torch.arange(n, device=logits.device)
    mask[idx, idx] = True
    logits = logits.masked_fill(mask, -torch.inf)
    return F.cross_entropy(logits, n + idx)


class Highway(nn.Module):
    def __init__(self, width: int):
        super().__init__()
        self.transform = nn.Linear(width, width)
        self.carry = nn.Linear(width, width)

    def forward(self, x):
        # Literal manuscript gate: sigmoid(F), not an invented learned gate.
        gate = torch.sigmoid(x)
        return gate * F.relu(self.transform(x)) + (1 - gate) * self.carry(x)


class SGMDA(nn.Module):
    def __init__(self, features: FoldFeatures, activation="relu", highway_mode="auxiliary"):
        super().__init__()
        tensor = lambda x: torch.as_tensor(x, dtype=torch.float32)
        self.register_buffer("linear_d", tensor(features.linear_d))
        self.register_buffer("linear_m", tensor(features.linear_m))
        self.register_buffer("graph_d", tensor(features.graph_d))
        self.register_buffer("graph_m", tensor(features.graph_m))
        self.register_buffer("target_d", tensor(features.target_d))
        self.register_buffer("target_m", tensor(features.target_m))
        nd, dim = features.linear_d.shape
        self.gae_d = GAE(nd, dim, activation)
        self.gae_m = GAE(len(features.linear_m), dim, activation)
        self.highway = Highway(4 * dim)
        self.highway_mode = highway_mode
        if highway_mode == "auxiliary":
            self.training_scorer = nn.Linear(4 * dim, 1)
        elif highway_mode == "fixed":
            self.training_scorer = None
            self.highway.requires_grad_(False)
        else:
            raise ValueError("highway_mode must be auxiliary or fixed")

    def encode(self):
        return self.gae_d(self.graph_d), self.gae_m(self.graph_m)

    def pair_features(self, pairs, zd, zm):
        d, m = pairs[:, 0], pairs[:, 1]
        x = torch.cat((self.linear_d[d], zd[d], self.linear_m[m], zm[m]), dim=1)
        return self.highway(x)

    def regularizers(self, zd, zm, temperature):
        rec = (reconstruction_loss(zd, self.target_d) + reconstruction_loss(zm, self.target_m)) / 2
        cl = (contrastive_loss(self.linear_d, zd, temperature)
              + contrastive_loss(self.linear_m, zm, temperature)) / 2
        return rec, cl

