"""SGMDA research implementation; see docs/IMPLEMENTATION.md for deviations."""
__version__ = "0.1.0"

