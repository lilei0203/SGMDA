"""Dataset validation, immutable provenance, and repeatable 5-CV splits."""
from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from sklearn.model_selection import StratifiedKFold


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def array_sha256(array: np.ndarray) -> str:
    a = np.ascontiguousarray(array)
    return hashlib.sha256(str((a.shape, str(a.dtype))).encode() + a.tobytes()).hexdigest()


@dataclass
class Dataset:
    associations: np.ndarray  # diseases x miRNAs, always
    disease_semantic: np.ndarray
    diseases: np.ndarray
    mirnas: np.ndarray

    def validate(self):
        a, s = self.associations, self.disease_semantic
        if a.ndim != 2 or not np.isin(a, [0, 1]).all() or not a.any():
            raise ValueError("Associations must be a nonempty binary disease x miRNA matrix")
        if a.shape != (len(self.diseases), len(self.mirnas)):
            raise ValueError("Entity names do not match association axes")
        for names in (self.diseases, self.mirnas):
            if len(set(names.tolist())) != len(names) or any(not str(x).strip() for x in names):
                raise ValueError("Entity names must be nonempty and unique")
        if s.shape != (a.shape[0], a.shape[0]) or not np.isfinite(s).all():
            raise ValueError("Disease semantic matrix has invalid shape or values")
        if s.min() < 0 or s.max() > 1 or not np.allclose(s, s.T, atol=1e-6):
            raise ValueError("Disease semantic matrix must be symmetric and in [0,1]")
        if not np.allclose(np.diag(s), 1):
            raise ValueError("Disease semantic self-similarity must equal one")


def load_dataset(path: str | Path) -> Dataset:
    with np.load(path, allow_pickle=False) as z:
        data = Dataset(z["associations"].astype(np.float32), z["disease_semantic"].astype(np.float32),
                       z["diseases"], z["mirnas"])
    data.validate()
    return data


def prepare_mdformer(raw: Path, output: Path) -> dict:
    # Published files have no matrix header; name files each have a column header.
    def names(filename):
        with (raw / filename).open(encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
        return np.asarray([r[0].strip() for r in rows[1:] if r], dtype=str)

    expected = {
        "m_d.csv": "eb194359f2d33b6a8f84ddb67671d4689d4c39e3b7b7a8cd612766d33d4359f8",
        "d_ss.csv": "d435f3dcc6a62e651f05a7bc9e6f4f9ef81cded525526efa88350c71e7621097",
        "disease number.csv": "d3d9fd27c5295f06ff0f4fa1bd8fb1ce20b919f55d442989bd19886b8d177d14",
        "miRNA name.csv": "1df7515e0144a936dfc3fa9190b5f49fa0387df0687f417aa20a451e19afeab4",
    }
    for name, digest in expected.items():
        if file_sha256(raw / name) != digest:
            raise ValueError(f"Checksum mismatch: {name}; obtain the pinned source files")
    data = Dataset(
        np.loadtxt(raw / "m_d.csv", delimiter=",", dtype=np.float32).T.copy(),
        np.loadtxt(raw / "d_ss.csv", delimiter=",", dtype=np.float32),
        names("disease number.csv"), names("miRNA name.csv"),
    )
    data.validate()
    if data.associations.shape != (591, 853) or data.associations.sum() != 12446:
        raise ValueError("This is not the expected 591 x 853 / 12,446 association benchmark")
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, associations=data.associations, disease_semantic=data.disease_semantic,
                        diseases=data.diseases, mirnas=data.mirnas)
    report = {
        "source": "https://github.com/Linda908/MDformer",
        "commit": "07223704e2effd1de43689e840ce5365b4317a36",
        "source_files_sha256": expected,
        "disease_count": len(data.diseases), "mirna_count": len(data.mirnas),
        "positive_count": int(data.associations.sum()),
        "unlabeled_count": int((data.associations == 0).sum()),
        "axes": ["disease", "miRNA"], "dataset_sha256": file_sha256(output),
        "semantic_source": "Author-released d_ss.csv; MeSH version/preprocessing not independently reconstructed",
        "unused_source_features": ["d_gs.csv", "m_gs.csv", "m_fs.csv", "d_adj.npy", "m_adj.npy"],
    }
    output.with_suffix(".provenance.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def balanced_folds(a: np.ndarray, seed: int, folds: int = 5):
    positive = np.argwhere(a == 1)
    unknown = np.argwhere(a == 0)  # ORIGINAL matrix: never sample a held-out positive.
    if len(positive) < folds or len(unknown) < len(positive):
        raise ValueError("Insufficient positive or unlabeled pairs for balanced cross-validation")
    rng = np.random.default_rng(seed)
    negative = unknown[rng.choice(len(unknown), len(positive), replace=False)]
    pairs = np.concatenate([positive, negative]).astype(np.int64)
    labels = np.r_[np.ones(len(positive)), np.zeros(len(negative))].astype(np.int64)
    assignment = np.empty(len(labels), dtype=np.int64)
    for fold, (_, test) in enumerate(StratifiedKFold(folds, shuffle=True, random_state=seed).split(pairs, labels)):
        assignment[test] = fold
    return pairs, labels, assignment


def training_matrix(shape: tuple[int, int], pairs: np.ndarray, labels: np.ndarray) -> np.ndarray:
    a = np.zeros(shape, dtype=np.float32)
    p = pairs[labels == 1]
    a[p[:, 0], p[:, 1]] = 1
    return a

