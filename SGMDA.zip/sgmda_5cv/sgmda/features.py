"""ALL association-derived features accept only the current TRAINING matrix."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.utils.extmath import randomized_svd


def gip(profiles: np.ndarray, gamma0: float = 1.0) -> np.ndarray:
    profiles = np.asarray(profiles, dtype=np.float64)
    norm2 = np.einsum("ij,ij->i", profiles, profiles)
    if norm2.mean() == 0:
        raise ValueError("GIP needs at least one training association")
    distance2 = np.maximum(norm2[:, None] + norm2[None, :] - 2 * profiles @ profiles.T, 0)
    result = np.exp(-gamma0 / norm2.mean() * distance2)
    np.fill_diagonal(result, 1)
    return result.astype(np.float32)


def misim(a_train: np.ndarray, semantic: np.ndarray) -> np.ndarray:
    """Symmetric best-match disease-set similarity, using ONLY training edges.

    b[d,m] = max semantic[d, disease] over diseases linked to m in training.
    a.T @ b gives all directional set-similarity sums at once.
    Empty disease sets yield zero, enabling the GIP fallback.
    """
    a = np.asarray(a_train, dtype=np.float64)
    counts = a.sum(axis=0)
    best = np.zeros_like(a)
    for m in range(a.shape[1]):
        linked = np.flatnonzero(a[:, m])
        if len(linked):
            best[:, m] = semantic[:, linked].max(axis=1)
    directional = a.T @ best
    denom = counts[:, None] + counts[None, :]
    usable = (counts[:, None] > 0) & (counts[None, :] > 0)
    score = np.divide(directional + directional.T, denom,
                      out=np.zeros_like(denom), where=usable)
    return np.clip(score, 0, 1).astype(np.float32)


def binary_graph(similarity: np.ndarray, threshold: float) -> tuple[np.ndarray, np.ndarray]:
    """Return off-diagonal reconstruction target and normalized encoder graph."""
    edges = (similarity > threshold).astype(np.float32)
    np.fill_diagonal(edges, 0)
    encoder = edges + np.eye(len(edges), dtype=np.float32)
    inv = np.power(encoder.sum(axis=1), -0.5)
    normalized = inv[:, None] * encoder * inv[None, :]
    return edges, normalized


@dataclass
class FoldFeatures:
    linear_d: np.ndarray
    linear_m: np.ndarray
    target_d: np.ndarray
    target_m: np.ndarray
    graph_d: np.ndarray
    graph_m: np.ndarray
    gip_d: np.ndarray
    gip_m: np.ndarray
    functional_m: np.ndarray


def build_features(a_train: np.ndarray, semantic: np.ndarray, dim: int = 64,
                   threshold: float = 0.5, seed: int = 42) -> FoldFeatures:
    if dim < 1 or dim > min(a_train.shape):
        raise ValueError("Embedding dimension must be between 1 and min(matrix.shape)")
    if not 0 <= threshold < 1:
        raise ValueError("Graph threshold must be in [0,1)")
    u, _, vt = randomized_svd(a_train, n_components=dim, n_iter=7, random_state=seed)
    gd, gm = gip(a_train), gip(a_train.T)
    functional = misim(a_train, semantic)
    integrated_d = np.where(semantic > 0, semantic, gd)
    integrated_m = np.where(functional > 0, functional, gm)
    td, nd = binary_graph(integrated_d, threshold)
    tm, nm = binary_graph(integrated_m, threshold)
    return FoldFeatures(u.astype(np.float32), vt.T.copy().astype(np.float32),
                        td, tm, nd, nm, gd, gm, functional)

