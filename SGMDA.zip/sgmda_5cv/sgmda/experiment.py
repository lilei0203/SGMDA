"""Auditable repeated 5-CV with saved splits, OOF predictions and run-level SD."""
from __future__ import annotations

import csv
import hashlib
import json
import platform
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import scipy
import sklearn
import torch
from threadpoolctl import threadpool_limits

from .data import array_sha256, balanced_folds, file_sha256, load_dataset, training_matrix
from .features import build_features
from .metrics import METRICS, evaluate, summarize
from .train import Config, train_fold


def write_json(path, obj):
    path = Path(path)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def write_csv(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def code_digest():
    h = hashlib.sha256()
    for p in sorted(Path(__file__).parent.glob("*.py")):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def run_experiment(dataset_path: Path, output: Path, config: Config, resume=False):
    config.validate()
    data = load_dataset(dataset_path)
    output.mkdir(parents=True, exist_ok=True)
    identity = {"config": asdict(config), "dataset_sha256": file_sha256(dataset_path),
                "code_sha256": code_digest()}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    manifest_path = output / "manifest.json"
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not resume or old["fingerprint"] != fingerprint:
            raise ValueError("Output already exists. Use a fresh folder, or --resume with identical code/config/data")
    else:
        if any(output.iterdir()):
            raise ValueError("Refusing to use a nonempty output folder without a manifest")
        write_json(manifest_path, {**identity, "fingerprint": fingerprint,
                   "dataset_path": str(dataset_path.resolve()), "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   "versions": {"python": platform.python_version(), "numpy": np.__version__,
                                "scipy": scipy.__version__, "sklearn": sklearn.__version__, "torch": torch.__version__},
                   "evaluation": "Within each run pool exactly one OOF score per sampled pair; summarize complete run metrics with sample SD (ddof=1).",
                   "AUPR_definition": "average_precision_score; trapezoidal PR-AUC saved separately",
                   "threshold": "Prespecified fixed probability threshold; no outer-test tuning",
                   "implementation_extension": "Training-only differentiable scorer for Highway (auxiliary mode); final predictions use RF"})
    all_runs = []
    all_folds = []
    a = data.associations
    for run in range(config.runs):
        seed = config.seed + 1000 * run
        pairs, labels, assignment = balanced_folds(a, seed, config.folds)
        run_dir = output / f"run_{run + 1:02d}"
        run_dir.mkdir(exist_ok=True)
        np.savez_compressed(run_dir / "split.npz", pairs=pairs, labels=labels, fold=assignment)
        scores = np.full(len(labels), np.nan)
        for fold in range(config.folds):
            fold_dir = run_dir / f"fold_{fold + 1}"
            fold_dir.mkdir(exist_ok=True)
            done = fold_dir / "complete.json"
            train, test = np.flatnonzero(assignment != fold), np.flatnonzero(assignment == fold)
            train_ids = np.ravel_multi_index(pairs[train].T, a.shape)
            test_ids = np.ravel_multi_index(pairs[test].T, a.shape)
            pair_overlap = int(np.intersect1d(train_ids, test_ids).size)
            if pair_overlap:
                raise AssertionError("Training and test pairs overlap")
            if resume and done.exists():
                record = json.loads(done.read_text(encoding="utf-8"))
                if record["fingerprint"] != fingerprint:
                    raise ValueError("Fold fingerprint mismatch")
                for name, digest in record["artifact_sha256"].items():
                    if file_sha256(fold_dir / name) != digest:
                        raise ValueError(f"Corrupted fold artifact: {fold_dir / name}")
                with np.load(fold_dir / "predictions.npz", allow_pickle=False) as p:
                    if not np.array_equal(p["indices"], test) or not np.array_equal(p["labels"], labels[test]):
                        raise ValueError("Saved predictions disagree with the regenerated split")
                    scores[test] = p["scores"]
                all_folds.append(record["metrics"])
                print(f"run {run + 1}/{config.runs} fold {fold + 1}/5: verified resume", flush=True)
                continue
            start = time.perf_counter()
            a_train = training_matrix(a.shape, pairs[train], labels[train])
            test_positive = pairs[test][labels[test] == 1]
            if a_train[test_positive[:, 0], test_positive[:, 1]].any():
                raise AssertionError("Held-out positive edge leaked into training graph")
            fold_seed = seed + fold + 1
            print(f"run {run + 1}/{config.runs} fold {fold + 1}/5: reconstructing features", flush=True)
            with threadpool_limits(limits=config.threads):
                features = build_features(a_train, data.disease_semantic, config.dim, config.graph_threshold, fold_seed)
            np.savez_compressed(fold_dir / "training_associations.npz", associations=a_train)

            def progress(row):
                print(f"  epoch {row['epoch']}/{config.epochs}: loss={row['total_loss']:.5f} "
                      f"Highway_grad={row['highway_gradient_norm']:.5g}", flush=True)

            prediction, model, rf, logs, diagnostic = train_fold(
                features, pairs[train], labels[train], pairs[test], config, fold_seed, progress)
            scores[test] = prediction
            fold_metrics = {"run": run + 1, "fold": fold + 1,
                            **evaluate(labels[test], prediction, config.classification_threshold)}
            all_folds.append(fold_metrics)
            write_csv(fold_dir / "training_log.csv", logs)
            audit = {"training_positive_count": int(labels[train].sum()),
                     "training_negative_count": int((labels[train] == 0).sum()),
                     "test_positive_count": int(labels[test].sum()),
                     "test_negative_count": int((labels[test] == 0).sum()),
                     "training_test_pair_overlap": pair_overlap,
                     "train_matrix_sha256": array_sha256(a_train),
                     "gip_d_sha256": array_sha256(features.gip_d), "gip_m_sha256": array_sha256(features.gip_m),
                     "misim_sha256": array_sha256(features.functional_m),
                     "linear_d_sha256": array_sha256(features.linear_d),
                     "linear_m_sha256": array_sha256(features.linear_m),
                     "graph_d_sha256": array_sha256(features.graph_d), "graph_m_sha256": array_sha256(features.graph_m),
                     "seed": fold_seed, "seconds": time.perf_counter() - start, **diagnostic}
            write_json(fold_dir / "audit.json", audit)
            np.savez_compressed(fold_dir / "predictions.npz", indices=test, pairs=pairs[test],
                                labels=labels[test], scores=prediction)
            if config.save_models:
                import joblib
                torch.save(model.state_dict(), fold_dir / "neural.pt")
                joblib.dump(rf, fold_dir / "random_forest.joblib")
            write_json(done, {"fingerprint": fingerprint, "metrics": fold_metrics,
                             "artifact_sha256": {name: file_sha256(fold_dir / name) for name in
                                                  ("predictions.npz", "audit.json", "training_log.csv", "training_associations.npz")}})
            print(f"  fold complete: AUC={fold_metrics['AUC']:.4f}, AP={fold_metrics['AUPR_AP']:.4f}, "
                  f"seconds={audit['seconds']:.1f}", flush=True)
            del model, rf, features
        if not np.isfinite(scores).all():
            raise AssertionError("Missing OOF predictions; do not report an incomplete run")
        run_metrics = {"run": run + 1, **evaluate(labels, scores, config.classification_threshold)}
        all_runs.append(run_metrics)
        write_csv(run_dir / "oof_predictions.csv", [
            {"disease_index": int(d), "mirna_index": int(m), "disease": str(data.diseases[d]),
             "mirna": str(data.mirnas[m]), "fold": int(f) + 1, "label": int(y),
             "score": float(s), "prediction": int(s >= config.classification_threshold)}
            for (d, m), f, y, s in zip(pairs, assignment, labels, scores)])
        write_json(run_dir / "metrics.json", run_metrics)
        write_csv(output / "run_metrics.csv", all_runs)
        write_csv(output / "fold_metrics.csv", all_folds)
        write_json(output / "summary.json", {"completed_runs": len(all_runs), "planned_runs": config.runs,
                                             "complete": len(all_runs) == config.runs, "metrics": summarize(all_runs)})
    summary = summarize(all_runs)
    lines = ["# SGMDA 5-CV results", "", f"Completed runs: {len(all_runs)}; epochs per fold: {config.epochs}.",
             f"Highway mode: `{config.highway_mode}`. All values are computed from saved OOF predictions.",
             "", "| Metric | Mean | Sample SD |", "|---|---:|---:|"]
    for name in METRICS:
        sd = summary[name]["std"]
        sd_text = "not estimable (one run)" if sd is None else f"{sd:.6f}"
        lines.append(f"| {name} | {summary[name]['mean']:.6f} | {sd_text} |")
    (output / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return summary

