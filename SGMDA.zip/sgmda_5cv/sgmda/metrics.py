"""Metrics computed from saved held-out predictions, never invented errors."""
import numpy as np
from sklearn.metrics import (accuracy_score, average_precision_score, auc,
                             confusion_matrix, f1_score, log_loss,
                             precision_recall_curve, precision_score,
                             recall_score, roc_auc_score)


def evaluate(labels, scores, threshold=0.5):
    labels, scores = np.asarray(labels), np.asarray(scores)
    if set(np.unique(labels)) != {0, 1}:
        raise ValueError("Both classes are required for evaluation")
    if not np.isfinite(scores).all() or np.any((scores < 0) | (scores > 1)):
        raise ValueError("RF scores must be finite probabilities in [0,1]")
    prediction = (scores >= threshold).astype(int)
    p, r, _ = precision_recall_curve(labels, scores)
    tn, fp, fn, tp = confusion_matrix(labels, prediction, labels=[0, 1]).ravel()
    return {"AUC": float(roc_auc_score(labels, scores)),
            "AUPR_AP": float(average_precision_score(labels, scores)),
            "PR_AUC_trapezoid": float(auc(r, p)),
            "ACC": float(accuracy_score(labels, prediction)),
            "Precision": float(precision_score(labels, prediction, zero_division=0)),
            "Recall": float(recall_score(labels, prediction, zero_division=0)),
            "F1": float(f1_score(labels, prediction, zero_division=0)),
            "BCE_evaluation_only": float(log_loss(labels, scores, labels=[0, 1])),
            "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)}


METRICS = ("AUC", "AUPR_AP", "PR_AUC_trapezoid", "ACC", "Precision", "Recall", "F1", "BCE_evaluation_only")


def summarize(runs):
    return {key: {"mean": float(np.mean([r[key] for r in runs])),
                  "std": float(np.std([r[key] for r in runs], ddof=1)) if len(runs) > 1 else None,
                  "n_runs": len(runs)} for key in METRICS}
