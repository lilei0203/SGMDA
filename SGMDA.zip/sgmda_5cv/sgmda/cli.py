from __future__ import annotations

import argparse
import json
from dataclasses import fields
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="SGMDA: fold-specific HMDD v3.2 five-fold CV")
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser("prepare", help="Validate pinned source files and prepare the dataset")
    prepare.add_argument("--raw", type=Path, default=Path("data/raw/mdformer"))
    prepare.add_argument("--output", type=Path, default=Path("data/processed/hmdd32.npz"))
    run = commands.add_parser("run", help="Run complete repeated five-fold cross-validation")
    run.add_argument("--config", type=Path, default=Path("configs/default.json"))
    run.add_argument("--data", type=Path, default=Path("data/processed/hmdd32.npz"))
    run.add_argument("--output", type=Path, required=True)
    run.add_argument("--runs", type=int)
    run.add_argument("--epochs", type=int)
    run.add_argument("--rf-trees", type=int)
    run.add_argument("--threads", type=int)
    run.add_argument("--device")
    run.add_argument("--save-models", action="store_true")
    run.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.command == "prepare":
        from .data import prepare_mdformer
        print(json.dumps(prepare_mdformer(args.raw, args.output), indent=2))
    else:
        from .train import Config
        from .experiment import run_experiment
        settings = json.loads(args.config.read_text(encoding="utf-8"))
        unknown = set(settings) - {f.name for f in fields(Config)}
        if unknown:
            parser.error(f"Unknown settings: {sorted(unknown)}")
        for name in ("runs", "epochs", "rf_trees", "threads", "device"):
            if getattr(args, name) is not None:
                settings[name] = getattr(args, name)
        if args.save_models:
            settings["save_models"] = True
        summary = run_experiment(args.data, args.output, Config(**settings), args.resume)
        print(json.dumps(summary, indent=2))

