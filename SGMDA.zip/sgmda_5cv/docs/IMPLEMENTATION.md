# 实现决策与论文的对应关系

本项目依据用户在 2026-10-03 提供的稿件，以及对“SVD 不更新”的明确说明编写。它是新实现，不能声称原文既有结果来自本代码。

## 已按稿件实现

- 矩阵方向为 disease × miRNA；处理后数据 591 × 853，12,446 个已知正关联。
- 每次运行重新采样 1:1 未标注负例；20 次运行；5 个随机折。
- 每折重新构造关联矩阵；SVD、GIP、miRNA 功能相似性都只接受训练矩阵。
- 两种相似性融合使用稿件的“优先语义/功能相似性，值为零时回退 GIP”，不是加权求和。
- 相似性严格大于 0.5 才连边；编码器加入自环和对称度归一化。
- 节点特征是 identity；`A_norm @ W` 与 `A_norm @ I @ W` 等价。
- 单层 GCN + ReLU 的 GAE，内积解码；SVD 使用 U 和 V 的行，不乘奇异值。
- 64 维线性与非线性表示；两实体四组表示拼接为 256 维 pair features。
- Highway 使用 `g=sigmoid(F)`、可训练 `t(F)=ReLU(W_t F+b_t)` 与 `q(F)=W_q F+b_q`，保持稿件门控形式。
- 最终分类器为 RF，RF 独立训练，不参与梯度计算。

## 必须公开说明的补足与偏差

### 1. Highway 如何训练

稿件中的“Highway → RF → BCE”不足以训练 Highway，因为普通随机森林不可微。默认 `highway_mode=auxiliary` 额外加入一个**仅用于训练**的线性层：

```text
fixed SVD ------> concatenate ----> Highway ---> linear score ---> BCE(train labels)
                    ^
GAE ---------------+
 |                  |
 +--> graph BCE     +--> cosine contrastive loss against fixed SVD

after neural training:
fixed Highway features ---> RandomForest.fit ---> final test probabilities
```

神经训练总目标为：

`L = 1.0 * mean(L_rec_d, L_rec_m) + 0.1 * mean(L_CL_d, L_CL_m) + 1.0 * L_pair_BCE`。

每个 epoch 进行一次优化器更新。为减少内存，pair BCE 分块累积梯度，然后将图重建和对比目标的梯度累积到同一组参数，最后统一 `optimizer.step()`。这在数学上是一个总损失的梯度，不是三个独立阶段。

这个设计是本次新实现的工程补足，**不能写成原稿已经采用了辅助评分层**。要据此产生论文实验结果，应相应更新方法和重新运行实验。

`highway_mode=fixed` 不增加评分层，只优化 GAE 的图重建和对比损失，Highway 参数保持随机初始化。这种模式可以检查“无可微损失接入 Highway”的具体行为，但不能声称 Highway 学到了特征交互。不要把它标为原模型的精确复现，因为原 Highway 初始化等细节亦未提供。

### 2. 对比学习

SVD 表示注册为固定 buffer，无投影层，无梯度。固定线性表示是 anchor；同一实体的 GAE 表示为正配对，其余实体的两种视图都是负例。使用余弦相似度与温度 0.2。只通过 GAE 视图反传。

稿件的分母包含 anchor 自己，本实现排除了这一项，但保留正配对在归一化分母中。这是明确的公式修正，不应隐瞒。损失对所有实体取均值而非未经缩放的求和，避免疾病数/miRNA 数差异造成比例失衡。

### 3. GAE 图重建

重建对象是各自的方形相似性图，不是矩形关联矩阵。重建目标排除对角线，自环只用于编码器传播。疾病与 miRNA 两个 BCE 分别取均值后平均。不使用由完整关联矩阵产生的图。

默认 ReLU 潜变量遵循稿件，但非负潜变量的内积会使解码概率不低于 0.5，可能限制稀疏图重建能力。`gae_activation=linear` 可研究有符号潜变量的变体；它属于方法变体，不应不加说明地替换默认模型或据测试集选取。

### 4. 疾病语义相似性来源

直接采用已发表 MDformer 仓库 HMDD3/d_ss.csv，与同一仓库的疾病顺序一致。它是作者发布的疾病语义相似性数据，不使用完整 HMDD 关联矩阵在本项目中计算。

本项目未重新下载某一历史版 MeSH 来重建 SS1/SS2，无法独立确认源文件的 MeSH 版本、映射规则和它与用户原实验 SS1/SS2 的逐元素一致性。数据规模匹配不等于完整数据处理过程完全一致。如取得原实验的疾病语义矩阵，应保持疾病名称顺序一致后替换，并保存新的 provenance。

miRNA 功能相似性不采用作者提供的 m_fs.csv，而是按稿件的双向疾病集合最佳匹配公式在当前训练折重新计算。某个 miRNA 在训练中无关联时，功能相似性设为 0，按稿件规则回退到 GIP；不会把测试关联补回去。

### 5. 未明确设置的默认值

| 设置 | 本项目默认 | 原因/出处 |
|---|---|---|
| epoch | 100，固定，无测试集 early stopping | 原稿未给出，研究起点 |
| optimizer | Adam，lr=0.001，无 weight decay | 学习率来自稿件；其余为明确默认 |
| contrastive temperature | 0.2 | 原稿未给值，非已验证最优值 |
| loss weights | rec 1 / CL 0.1 / prediction 1 | 本实现选择，均采用 mean reduction |
| RF | 300 棵树，gini，sqrt 特征，bootstrap，leaf=1 | 原稿未给出，显式采用 sklearn 常规设置 |
| RF 最大深度 | None | 未根据外层测试结果选择 |
| 分类阈值 | 0.5，score >= threshold 判正 | 固定先验规则，避免伪称已做训练内阈值搜索 |
| folds | shuffled StratifiedKFold(5) | 保持各折正负比例，属于明确的划分实现选择 |
| SVD | randomized_svd，n_iter=7，固定种子 | 截断 SVD 的计算实现 |
| GIP gamma0 | 1；带宽按训练 interaction profiles 重算 | 常见标准定义，稿件未给初始值 |
| AUPR | AP；另存梯形 PR-AUC | 消除不同实现之间的歧义 |
| 运行级指标 | pooled OOF | 每个采样样本恰好一次测试预测 |
| SD | 对完整运行的指标取 ddof=1 | 不把折数当独立重复次数 |

所有这些默认值在训练前确定；不能为了匹配原表数值使用外层测试折反复选择设置。需要调参时，应增加训练内验证，并对内层验证同样重建关联衍生特征。本版本不声称实现了 nested CV。

## 本版本的范围

仅 SGMDA 的 pair-wise 5-CV。没有 LOOCV、M-CV、D-CV、其他模型的伪实现、自动 P 值、文献表格数值植入或虚构 SD。不同生物学实体留出协议与当前 pair-wise 评价不是同一件事。

