# 数据与方法来源

检索日期：2026-10-03。下列资料用于确定数据来源、已有方法定义及合理实现方式；并不表示所有默认超参数均由这些文献给出。

1. **HMDD 官方下载页**：[HMDD](https://www.cuilab.cn/hmdd)。页面保留 Part B “HMDD v3.2 data (version 2019.01)”。本项目使用下面作者发布的清洗基准，不把 12,446 对写成原始数据库总量。
2. **MDformer 原论文**：[MDformer: A transformer-based method for predicting miRNA-Disease associations using multi-source feature fusion and maximal meta-path instances encoding](https://www.sciencedirect.com/science/article/pii/S0010482523010508)。论文描述了 853 个 miRNA、591 个疾病、12,446 个关联，并提供作者代码/数据。
3. **MDformer 作者数据仓库**：[Linda908/MDformer](https://github.com/Linda908/MDformer)。锁定提交 `07223704e2effd1de43689e840ce5365b4317a36`，只下载 `HMDD3/m_d.csv`、`HMDD3/d_ss.csv`、`HMDD3/disease number.csv`、`HMDD3/miRNA name.csv`。
4. **GCAEMDA**：[Predicting miRNA-disease associations via graph convolutional autoencoder](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1009655)。报告同一规模的 HMDD v3.2 清洗基准，为规模交叉核验来源。
5. **图自编码器**：Kipf and Welling, [Variational Graph Auto-Encoders](https://arxiv.org/abs/1611.07308)，及其 [官方实现](https://github.com/tkipf/gae)。本项目实现的是确定性 GAE，而非变分模型。
6. **Highway**：Srivastava, Greff and Schmidhuber, [Highway Networks](https://arxiv.org/abs/1505.00387)。本项目默认门控仍按用户稿件 `sigmoid(F)`；没有把原始 Highway 的全部结构细节假称为用户模型。
7. **指标与阈值**：[average_precision_score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html)、[classification thresholds](https://scikit-learn.org/stable/modules/classification_threshold.html)。AP 与梯形 PR-AUC 分开保存。

所有外部数据的权利归原作者/数据库所有。本项目不对外部数据另行授予许可；公开再分发或发表时应引用数据与论文，并核实相应使用条款。未复制上游模型代码。

