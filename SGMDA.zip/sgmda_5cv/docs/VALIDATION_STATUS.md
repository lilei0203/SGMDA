# 当前验证状态

按用户“先不用做测试，先把完整代码生成”的要求，停止后续测试及实验运行。

## 已完成的数据检查

- 公开来源文件已下载，固定上游 commit 并记录 SHA-256。
- 关联矩阵源方向为 853 × 591，内部转置为 591 × 853；元素均为 0/1，正关联数为 12,446。
- 疾病语义矩阵为 591 × 591，数值位于 [0,1]，对称，对角线为 1。
- 已生成 `data/processed/hmdd32.npz` 和对应来源清单。

## 用户停止测试前的局部检查

旧代码状态下，8 个协议/特征/梯度/指标测试通过；第 9 个端到端测试因 Windows 沙箱无法访问 pytest 临时目录而未能执行。

真实数据的小配置运行仅到第一折的两轮神经训练，日志显示 Highway 非零梯度；随后 RF 的多线程句柄创建被 Windows 沙箱拒绝。未完成第一折评价，更未完成一次五折实验。这些中间数值不是模型性能结果。

此后加入线程数控制和文档/辅助脚本，遵照要求未再执行测试。因此不声称最终交付版已通过完整测试。

## 后续由用户决定何时运行

```bash
python -m pytest -c pyproject.toml -q
python -m sgmda run --config configs/smoke.json --output results/new_smoke
python -m sgmda run --config configs/default.json --runs 1 --output results/new_one_run
python -m sgmda run --config configs/default.json --output results/new_twenty_runs
```

如果在 Codex 的 Windows 沙箱中执行，pytest 的临时目录或 RF 的并行运行可能需要宿主机运行权限。这是环境限制，不应据此伪造成功状态。普通本地终端可使用自建虚拟环境运行。

项目压缩包不包含未完成实验目录、pytest 缓存或测试临时文件。
