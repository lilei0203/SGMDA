import json
from dataclasses import replace

import numpy as np
import pytest
import torch
from sklearn.metrics import f1_score

from sgmda.data import balanced_folds, load_dataset, training_matrix
from sgmda.experiment import run_experiment
from sgmda.features import binary_graph, build_features, gip, misim
from sgmda.metrics import evaluate, summarize
from sgmda.model import SGMDA, contrastive_loss
from sgmda.train import Config, seed_everything, train_fold


def example():
    rng = np.random.default_rng(28)
    a = np.zeros((10, 12), dtype=np.float32)
    chosen = rng.choice(a.size, 30, replace=False)
    a.flat[chosen] = 1
    x = rng.normal(size=(10, 4))
    distance = ((x[:, None] - x[None, :]) ** 2).sum(axis=-1)
    semantic = np.exp(-distance).astype(np.float32)
    return a, semantic


def test_every_pair_tested_once_with_disjoint_train_test_and_no_hidden_positive_negatives():
    a, _ = example()
    pairs, y, folds = balanced_folds(a, 40)
    assert len(set(map(tuple, pairs))) == len(pairs)
    assert (y == 1).sum() == (y == 0).sum() == int(a.sum())
    assert not a[pairs[y == 0, 0], pairs[y == 0, 1]].any()
    tested = []
    for k in range(5):
        train, test = folds != k, folds == k
        assert not set(map(tuple, pairs[train])) & set(map(tuple, pairs[test]))
        masked = training_matrix(a.shape, pairs[train], y[train])
        assert not masked[pairs[test, 0], pairs[test, 1]].any()
        assert masked.sum() == y[train].sum()
        tested.extend(np.flatnonzero(test))
    assert sorted(tested) == list(range(len(y)))
    again = balanced_folds(a, 40)
    assert all(np.array_equal(x, z) for x, z in zip((pairs, y, folds), again))
    assert not np.array_equal(pairs, balanced_folds(a, 41)[0])


def test_misim_matches_hand_computation_and_empty_profiles_fall_back():
    a = np.array([[1, 0, 0], [1, 1, 0], [0, 1, 0]], dtype=np.float32)
    s = np.array([[1, .2, .1], [.2, 1, .4], [.1, .4, 1]], dtype=np.float32)
    value = misim(a, s)
    # Sets {0,1}, {1,2}: (.2+1+1+.4)/4 = .65
    assert value[0, 1] == pytest.approx(.65)
    assert np.allclose(value, value.T)
    assert np.allclose(value.diagonal(), [1, 1, 0])
    assert not value[2].any()
    f = build_features(a, s, dim=2)
    integrated = np.where(f.functional_m > 0, f.functional_m, f.gip_m)
    assert np.array_equal(integrated[2], f.gip_m[2])


def test_features_depend_only_on_masked_training_edges():
    a, s = example()
    pairs, y, folds = balanced_folds(a, 12)
    mask = folds != 0
    masked = training_matrix(a.shape, pairs[mask], y[mask])
    hidden = pairs[(folds == 0) & (y == 1)][0]
    f = build_features(masked, s, dim=3, seed=4)
    full = masked.copy()
    full[tuple(hidden)] = 1
    leaked = build_features(full, s, dim=3, seed=4)
    assert not np.allclose(f.gip_d, leaked.gip_d)
    assert not np.allclose(f.gip_m, leaked.gip_m)
    assert not np.allclose(f.linear_d, leaked.linear_d)
    assert not np.allclose(f.functional_m, leaked.functional_m)
    # Pipeline inputs exclude the hidden edge and reproduce the original features.
    fresh = build_features(training_matrix(a.shape, pairs[mask], y[mask]), s, dim=3, seed=4)
    assert np.array_equal(f.functional_m, fresh.functional_m)
    assert np.array_equal(f.linear_d, fresh.linear_d)


def test_gip_and_graph_normalization():
    profile = np.array([[1, 0], [0, 1]], dtype=np.float32)
    assert gip(profile)[0, 1] == pytest.approx(np.exp(-2))
    target, graph = binary_graph(np.array([[1, .5], [.5, 1]]), .5)
    assert not target.any()  # Strictly greater than .5, not >=.
    assert np.array_equal(graph, np.eye(2))


def test_contrastive_only_updates_nonlinear_side():
    fixed = torch.randn(5, 3, requires_grad=True)
    learned = torch.randn(5, 3, requires_grad=True)
    loss = contrastive_loss(fixed, learned, .2)
    loss.backward()
    assert fixed.grad is None
    assert learned.grad is not None and learned.grad.norm() > 0


def test_supervised_gradient_reaches_highway_and_gae_but_not_svd():
    a, s = example()
    seed_everything(42, 1)
    model = SGMDA(build_features(a, s, dim=3), activation="linear")
    pairs = torch.tensor([[0, 0], [1, 1], [2, 2], [3, 3]])
    zd, zm = model.encode()
    logits = model.training_scorer(model.pair_features(pairs, zd, zm)).squeeze(1)
    torch.nn.functional.binary_cross_entropy_with_logits(logits, torch.tensor([1., 0., 1., 0.])).backward()
    assert model.highway.carry.weight.grad.norm() > 0
    assert model.gae_d.weight.grad.norm() > 0
    assert model.gae_m.weight.grad.norm() > 0
    assert not model.linear_d.requires_grad and model.linear_d.grad is None


def test_fixed_mode_does_not_claim_to_train_highway():
    a, s = example()
    pairs, y, folds = balanced_folds(a, 11)
    ix = folds != 0
    feat = build_features(training_matrix(a.shape, pairs[ix], y[ix]), s, dim=3)
    cfg = Config(runs=1, dim=3, epochs=1, rf_trees=3, threads=1, highway_mode="fixed")
    _, _, _, logs, audit = train_fold(feat, pairs[ix], y[ix], pairs[~ix], cfg, 12)
    assert audit["highway_parameter_delta_l2"] == 0
    assert logs[0]["highway_gradient_norm"] == 0
    assert logs[0]["association_BCE"] is None


def test_metrics_and_run_sd_come_from_predictions():
    y = np.array([1, 1, 0, 0, 1, 0])
    p = np.array([.9, .4, .2, .8, .6, .1])
    result = evaluate(y, p)
    assert result["F1"] == pytest.approx(f1_score(y, p >= .5))
    assert result["F1"] == pytest.approx(2 * result["Precision"] * result["Recall"] /
                                         (result["Precision"] + result["Recall"]))
    assert summarize([result])["F1"]["std"] is None
    other = evaluate(y, np.array([.9, .8, .2, .1, .6, .1]))
    expected = np.std([result["F1"], other["F1"]], ddof=1)
    assert summarize([result, other])["F1"]["std"] == pytest.approx(expected)


def test_end_to_end_saved_predictions_reproduce_metrics_and_resume(tmp_path):
    a, s = example()
    dataset = tmp_path / "synthetic.npz"
    np.savez_compressed(dataset, associations=a, disease_semantic=s,
                        diseases=np.array([f"d{i}" for i in range(10)]),
                        mirnas=np.array([f"m{i}" for i in range(12)]))
    assert load_dataset(dataset).associations.shape == (10, 12)
    cfg = Config(runs=2, dim=3, epochs=1, rf_trees=3, threads=1, batch_size=8)
    output = tmp_path / "result"
    result = run_experiment(dataset, output, cfg)
    saved = np.genfromtxt(output / "run_01/oof_predictions.csv", delimiter=",", names=True, dtype=None, encoding="utf-8")
    assert len(saved) == 60
    checked = evaluate(saved["label"], saved["score"])
    first = json.loads((output / "run_01/metrics.json").read_text())
    assert first["AUC"] == checked["AUC"]
    assert first["F1"] == checked["F1"]
    assert all(v["std"] is not None for v in result.values())
    assert run_experiment(dataset, output, cfg, resume=True) == result
    with pytest.raises(ValueError, match="already exists"):
        run_experiment(dataset, output, replace(cfg, epochs=2), resume=True)
    with (output / "run_01/fold_1/predictions.npz").open("ab") as f:
        f.write(b"tampered")
    with pytest.raises(ValueError, match="Corrupted"):
        run_experiment(dataset, output, cfg, resume=True)
